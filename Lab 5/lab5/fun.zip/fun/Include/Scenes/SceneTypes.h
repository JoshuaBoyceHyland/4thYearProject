#pragma once
enum SceneType 
{ 
	Menu, 
	ShipEditor, 
	RoomBuilder, 
	BaseBuilder, 
	BaseGameplay, 
	ShipGameplay, 
	DungeonGenerationTest,
	GeneratedDungionNPCTest, 
	EnemyBase
};