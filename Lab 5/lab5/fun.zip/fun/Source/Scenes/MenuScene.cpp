#include "Scenes/MenuScene.h"

MenuScene::MenuScene(sf::RenderWindow& t_window) : Scene( t_window )
{
}

void MenuScene::update(sf::Time t_deltaTime)
{
}

void MenuScene::render()
{
}

void MenuScene::processKeys(sf::Event t_event)
{

}

void MenuScene::processMousePress(sf::Event t_event)
{
}

void MenuScene::processMouseRelease(sf::Event t_event)
{
}

void MenuScene::processMouseMove(sf::Event t_event)
{
}


