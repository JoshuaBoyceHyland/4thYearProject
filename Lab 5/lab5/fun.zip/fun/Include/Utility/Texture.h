#pragma once
#include <SFML/Graphics.hpp>

struct Texture
{
	int id;
	sf::Texture texture;
};
