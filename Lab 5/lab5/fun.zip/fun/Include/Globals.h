#pragma once

#include "Utility/VectorMath.h"

namespace Globals {
	const int SCREEN_WIDTH = 1920;
	const int SCREEN_HEIGHT = 1080;
}
