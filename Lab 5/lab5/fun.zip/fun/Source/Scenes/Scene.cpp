#include "Scenes/Scene.h"

Scene::Scene(sf::RenderWindow& t_window) : m_window( t_window)
{
}

Scene::~Scene()
{
}
