#pragma once

enum class BehaviourType { Wander = 0 };