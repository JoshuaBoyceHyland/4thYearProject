#pragma once
#include "Scene.h"
#include "Librarys/Loader.h"

class MenuScene : Scene
{
	public:

		/// <summary>
		/// constructor for Editor scene
		/// Updates the mouses vector of scene parts
		/// </summary>
		/// <param name="t_window">Assigns to our reference so we can draw to the main window</param>
		MenuScene(sf::RenderWindow& t_window);

		/// <summary>
		/// Updates our objects in the scene
		/// </summary>
		/// <param name="t_deltaTime"></param>
		virtual void update(sf::Time t_deltaTime);

		/// <summary>
		/// Renders all objects
		/// </summary>
		virtual void render();

		/// <summary>
		/// Handles Key presses
		/// </summary>
		/// <param name="t_event">Key Press Event</param>
		virtual void processKeys(sf::Event t_event);

		/// <summary>
		/// Handles what to do with on mouse press
		/// </summary>
		/// <param name="t_event">Mouse Press Event</param>
		virtual void processMousePress(sf::Event t_event);

		/// <summary>
		/// Handles what to do with mouse release event
		/// </summary>
		/// <param name="t_event">Mouse release event</param>
		virtual void processMouseRelease(sf::Event t_event);

		/// <summary>
		/// Handles what to do withe a mouse move event
		/// </summary>
		/// <param name="t_event">Mouse move event</param>
		virtual void processMouseMove(sf::Event t_event);

		private:


		



	};

